
from flask import Flask,render_template,request
import pickle
import numpy as np

model = pickle.load(open('CatBoost.pkl','rb'))

Sc = pickle.load(open('scaler.pkl','rb'))#min max scaler 

app=Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict_species():
    Longitude = float(request.form.get("LG"))
    Latitude = float(request.form.get("LT"))
    Depth = float(request.form.get("DH"))
    Nst = int(request.form.get("NT"))
    Gap = float(request.form.get("GP"))
    MagNst = int(request.form.get("MN"))




    result = model.predict(np.array(Sc.transform([[Longitude,Latitude,Depth,Nst,Gap,MagNst]])).reshape(1,6))
    result=result.item()
    return render_template('result.html',result= "The Earthquake Magnitude is {:.2f}".format(result))
if __name__=='__main__':
    app.run(debug=True)